# GitHub Pages Deployment

1. Upload all files to a GitHub repository.
2. Go to Settings → Pages.
3. Deploy from Branch.
4. Select main branch and /(root).
5. Save.

Site will be available via GitHub Pages.
